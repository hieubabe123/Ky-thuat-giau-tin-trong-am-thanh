#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Tên file: compare_two_filesizes_arg_script.py

import os
import argparse # Sử dụng argparse để xử lý đối số dòng lệnh

def display_and_compare_file_sizes(filepath1, filepath2):
    """
    Hiển thị thông tin kích thước của hai file và so sánh chúng.
    """
    print(f"--- So sánh dung lượng ---")
    size1_bytes = None
    size2_bytes = None
    
    # Lấy tên file để hiển thị
    filename1 = os.path.basename(filepath1)
    filename2 = os.path.basename(filepath2)

    try:
        if not os.path.exists(filepath1):
            print(f"Lỗi: File 1 ('{filename1}') không tồn tại tại đường dẫn: '{filepath1}'")
        else:
            size1_bytes = os.path.getsize(filepath1)
            print(f"File 1 ('{filename1}'): {size1_bytes} bytes ({size1_bytes / 1024:.2f} KB)")
    except Exception as e:
        print(f"Lỗi khi lấy thông tin File 1 ('{filename1}'): {e}")

    try:
        if not os.path.exists(filepath2):
            print(f"Lỗi: File 2 ('{filename2}') không tồn tại tại đường dẫn: '{filepath2}'")
        else:
            size2_bytes = os.path.getsize(filepath2)
            print(f"File 2 ('{filename2}'): {size2_bytes} bytes ({size2_bytes / 1024:.2f} KB)")
    except Exception as e:
        print(f"Lỗi khi lấy thông tin File 2 ('{filename2}'): {e}")
        
    if size1_bytes is not None and size2_bytes is not None:
        if size1_bytes == size2_bytes:
            print(f"=> Kích thước của '{filename1}' và '{filename2}' BẰNG NHAU.")
        else:
            difference = abs(size1_bytes - size2_bytes)
            if size1_bytes > size2_bytes:
                print(f"=> '{filename1}' LỚN HƠN '{filename2}' {difference} bytes.")
            else:
                print(f"=> '{filename1}' NHỎ HƠN '{filename2}' {difference} bytes.")
    else:
        # Thông báo lỗi cụ thể đã được in ở trên nếu file không tồn tại
        if not (os.path.exists(filepath1) and os.path.exists(filepath2)):
             print("=> Không thể so sánh do một hoặc cả hai file không tồn tại.")
        else:
             print("=> Không thể so sánh do có lỗi khi đọc thông tin một hoặc cả hai file.")


# --- PHẦN CHÍNH CỦA SCRIPT SO SÁNH DUNG LƯỢNG ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="So sánh dung lượng của hai file được chỉ định.",
        epilog="Ví dụ cách chạy: python3 compare_two_filesizes_arg_script.py file_A.wav file_B.wav"
    )
    parser.add_argument(
        "file1", 
        type=str, 
        help="Đường dẫn đến file thứ nhất."
    )
    parser.add_argument(
        "file2", 
        type=str, 
        help="Đường dẫn đến file thứ hai."
    )
    
    args = parser.parse_args() # Phân tích các đối số

    print("===== SCRIPT SO SÁNH DUNG LƯỢNG HAI FILE =====")
    
    display_and_compare_file_sizes(args.file1, args.file2)

    print("\n===== HOÀN THÀNH SO SÁNH DUNG LƯỢNG =====")
    print("\nCompare File Size Successfully")