#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Tên file: calculate_audio_ber_arg_script.py

import os
import argparse
import numpy as np
from scipy.io import wavfile # Để đọc file WAV

def audio_data_to_bit_list(audio_data_array):
    """
    Chuyển đổi mảng dữ liệu âm thanh NumPy thành một danh sách các bit (0 và 1).
    """
    # Làm phẳng mảng nếu nó có nhiều chiều (ví dụ: stereo)
    # Thứ tự 'C' (C-like) sẽ làm phẳng theo hàng, nghĩa là các mẫu của kênh trái rồi đến kênh phải nếu interleaved.
    # Hoặc nếu bạn muốn xử lý kênh cụ thể, bạn cần chọn kênh trước khi gọi tobytes().
    # Ở đây, chúng ta làm phẳng để lấy toàn bộ dữ liệu byte thô.
    flat_data = audio_data_array.flatten() 
    
    # Chuyển mảng NumPy thành chuỗi byte thô
    byte_data = flat_data.tobytes()
    
    bit_list = []
    for byte_val in byte_data:
        # Chuyển mỗi byte thành 8 bit
        binary_representation = format(byte_val, '08b')
        bit_list.extend([int(b) for b in binary_representation])
    return bit_list

def calculate_ber_for_audio_files(original_audio_filepath, modified_audio_filepath):
    """
    Tính toán BER giữa dữ liệu của hai file âm thanh WAV.
    Trả về: (ber, số bit lỗi, tổng số bit gốc, thông báo lỗi nếu có)
    """
    try:
        fs_orig, data_orig = wavfile.read(original_audio_filepath)
        fs_mod, data_mod = wavfile.read(modified_audio_filepath)
    except FileNotFoundError as e:
        return None, None, None, f"Lỗi: Không tìm thấy file - {e.filename}"
    except Exception as e:
        return None, None, None, f"Lỗi khi đọc file WAV: {e}"

    print(f"Thông tin file gốc ('{os.path.basename(original_audio_filepath)}'): Fs={fs_orig}, Kiểu dữ liệu={data_orig.dtype}, Số kênh={data_orig.ndim}")
    print(f"Thông tin file sửa đổi ('{os.path.basename(modified_audio_filepath)}'): Fs={fs_mod}, Kiểu dữ liệu={data_mod.dtype}, Số kênh={data_mod.ndim}")

    if fs_orig != fs_mod:
        print(f"Cảnh báo: Tần số lấy mẫu khác nhau! ({fs_orig} Hz vs {fs_mod} Hz)")
    if data_orig.dtype != data_mod.dtype:
        print(f"Cảnh báo: Kiểu dữ liệu mẫu khác nhau! ({data_orig.dtype} vs {data_mod.dtype})")
    if data_orig.ndim != data_mod.ndim:
        print(f"Cảnh báo: Số kênh khác nhau! ({data_orig.ndim} vs {data_mod.ndim})")


    original_bits = audio_data_to_bit_list(data_orig)
    modified_bits = audio_data_to_bit_list(data_mod)

    len_orig_bits = len(original_bits)
    len_mod_bits = len(modified_bits)

    if len_orig_bits == 0:
        if len_mod_bits == 0:
            return 0.0, 0, 0, "Thông báo: Cả hai file âm thanh đều không có dữ liệu bit (0 bits)."
        else:
            return 1.0, len_mod_bits, 0, "Lỗi: File âm thanh gốc không có dữ liệu bit, nhưng file sửa đổi có. BER coi như 100%."

    error_bits_count = 0
    comparison_length = min(len_orig_bits, len_mod_bits)
    for i in range(comparison_length):
        if original_bits[i] != modified_bits[i]:
            error_bits_count += 1
    
    # Các bit thừa/thiếu cũng được tính là lỗi so với file gốc
    error_bits_count += abs(len_orig_bits - len_mod_bits)
    
    ber_value = error_bits_count / float(len_orig_bits)
    
    return ber_value, error_bits_count, len_orig_bits, None

# --- PHẦN CHÍNH CỦA SCRIPT TÍNH BER CHO FILE ÂM THANH ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Tính toán Tỷ lệ Lỗi Bit (BER) giữa hai file âm thanh WAV.",
        epilog="Ví dụ cách chạy: python3 calculate_audio_ber_arg_script.py am_thanh_goc.wav am_thanh_da_sua.wav"
    )
    parser.add_argument(
        "original_audio_file", 
        type=str, 
        help="Đường dẫn đến file WAV gốc (được coi là tham chiếu)."
    )
    parser.add_argument(
        "modified_audio_file", 
        type=str, 
        help="Đường dẫn đến file WAV đã bị sửa đổi hoặc đã giấu tin."
    )
    
    args = parser.parse_args()

    print("===== SCRIPT TÍNH TỶ LỆ LỖI BIT (BER) CHO FILE ÂM THANH WAV =====")
    
    ORIGINAL_AUDIO_FILE = args.original_audio_file
    MODIFIED_AUDIO_FILE = args.modified_audio_file

    print(f"\nĐang so sánh giữa '{ORIGINAL_AUDIO_FILE}' và '{MODIFIED_AUDIO_FILE}'...")
    
    ber, errors, total_bits, error_message = calculate_ber_for_audio_files(ORIGINAL_AUDIO_FILE, MODIFIED_AUDIO_FILE)
    
    if error_message:
        print(error_message)
    elif ber is not None:
        print(f"Tổng số bit trong dữ liệu âm thanh gốc ('{os.path.basename(ORIGINAL_AUDIO_FILE)}'): {total_bits} bits")
        print(f"Số bit lỗi giữa dữ liệu âm thanh gốc và sửa đổi: {errors} bits")
        print(f"Tỷ lệ Lỗi Bit (BER) của dữ liệu âm thanh: {ber:.8f} ({ber * 100:.4f}%)")
        if total_bits > 0:
            if ber == 0.0 and errors == 0:
                print("=> Kết luận: Dữ liệu âm thanh của hai file HOÀN TOÀN GIỐNG NHAU ở mức bit (BER = 0).")
            else:
                print("=> Kết luận: Dữ liệu âm thanh của hai file có sự khác biệt ở mức bit.")
        else:
            print("=> Kết luận: Không có dữ liệu bit trong file âm thanh gốc để so sánh.")
    else:
        print("Lỗi không xác định trong quá trình tính BER cho file âm thanh.")

    print("\n===== HOÀN THÀNH TÍNH BER CHO FILE ÂM THANH =====")
    print("\nCompare File BER Successfully")