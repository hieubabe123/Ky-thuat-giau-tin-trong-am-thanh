import numpy as np
import pmt
from gnuradio import gr

class fhss_modulator(gr.sync_block):
    """
    Embeds a BPSK signal using Frequency Hopping Spread Spectrum.
    Input 0: Complex BPSK baseband samples.
    Input 1: Stream of hop frequency indices (float, but treated as int).
    Output 0: Complex FHSS signal.
    """
    def __init__(self, samp_rate=44100.0, hop_list_hz=None, symbols_per_hop=1, samples_per_symbol=100):
        gr.sync_block.__init__(
            self,
            name='FHSS Modulator',
            in_sig=[np.complex64, np.float32],  # BPSK in, Hop index in
            out_sig=[np.complex64]
        )
        self.samp_rate = float(samp_rate)
        if hop_list_hz is None:
            self.hop_list_hz = [1000.0, 2000.0, 3000.0, 4000.0] # Default if not provided
        else:
            # Ensure hop_list_hz is a list of floats
            self.hop_list_hz = [float(f) for f in hop_list_hz]

        self.symbols_per_hop = int(symbols_per_hop)
        self.samples_per_symbol = int(samples_per_symbol)
        
        self.samples_per_hop_period = self.samples_per_symbol * self.symbols_per_hop
        
        self.current_hop_idx = 0
        self.current_hop_freq_hz = self.hop_list_hz[self.current_hop_idx]
        self.phase = 0.0
        self.sample_counter_in_hop = 0

        # For receiving hop index updates
        self.port_id_hop_idx = pmt.intern("hop_idx_port") # An arbitrary name
        self.message_port_register_in(self.port_id_hop_idx) # Register the message port
        self.set_msg_handler(self.port_id_hop_idx, self.handle_hop_idx_msg) # Set the handler

    def handle_hop_idx_msg(self, msg):
        """Handles messages on the hop_idx_port to update the hop index."""
        if pmt.is_f32vector(msg): # Check if it's a float vector (from Throttle output)
            # Assuming the throttle outputs one float at a time in a vector of len 1
            new_idx_val = pmt.f32vector_elements(msg)[0]
            new_idx = int(new_idx_val) % len(self.hop_list_hz)
            if new_idx != self.current_hop_idx:
                self.current_hop_idx = new_idx
                self.current_hop_freq_hz = self.hop_list_hz[self.current_hop_idx]
                # self.phase = 0.0 # Optional: Reset phase on hop
                # print(f"Hopped to index {self.current_hop_idx}, Freq: {self.current_hop_freq_hz} Hz")
        # For direct stream input (if not using message port)
        # This handler is for message port; direct stream input is handled by work()

    def work(self, input_items, output_items):
        in_bpsk = input_items[0]
        # in_hop_indices = input_items[1] # For direct stream input of hop indices

        num_samples_to_process = len(in_bpsk)
        out = output_items[0]

        for i in range(num_samples_to_process):
            # Check for hop index update from direct stream (if used)
            # This part needs to be adapted if in_hop_indices stream is used directly
            # and has a different rate than in_bpsk.
            # For now, relying on message port or assuming hop index changes slowly
            # relative to sample rate.
            # A more robust way is to consume from in_hop_indices stream when sample_counter_in_hop resets.

            if self.sample_counter_in_hop == 0: # Time to get a new hop frequency
                # This is where you'd consume from input_items[1] if it's a synced stream
                # For now, we assume the message handler has updated self.current_hop_freq_hz
                # or we use a simpler logic if input_items[1] is available at sample rate
                # (which is unlikely for hop control).
                # Let's assume handle_hop_idx_msg is working via a separate message passing mechanism
                # (e.g. Probe Signal -> Python Snippet -> Message Sink -> This Block's Message Port)
                # For a simpler direct stream input (if input_items[1] provides a new index when needed):
                # if len(input_items[1]) > 0: # Check if there's a new hop index available
                #    new_idx = int(input_items[1][0]) % len(self.hop_list_hz) # Consume one
                     # input_items[1] = input_items[1][1:] # Not how consumption works in work()
                #    if new_idx != self.current_hop_idx:
                #        self.current_hop_idx = new_idx
                #        self.current_hop_freq_hz = self.hop_list_hz[self.current_hop_idx]
                pass # Current hop frequency is managed by message handler or set at init


            # Generate complex sinusoid for current hop frequency
            lo_sample = np.exp(1j * self.phase)
            
            # Modulate BPSK sample to the hop frequency
            out[i] = in_bpsk[i] * lo_sample
            
            # Update phase for next sample
            self.phase += 2 * np.pi * self.current_hop_freq_hz / self.samp_rate
            if self.phase > np.pi: # Keep phase in [-pi, pi]
                self.phase -= 2 * np.pi
            
            self.sample_counter_in_hop += 1
            if self.sample_counter_in_hop >= self.samples_per_hop_period:
                self.sample_counter_in_hop = 0
                # The hop frequency itself should be updated by the message handler
                # or by consuming from input_items[1] if it's designed that way.

        return num_samples_to_process
